using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace TabsModLoader
{
    /// <summary>
    /// Attribute that identifies a mod class and gives it a display name.
    /// </summary>
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = false)]
    public sealed class TabsModAttribute : Attribute
    {
        public string Name { get; set; }
        public string Version { get; set; }
        public string Author { get; set; }

        public TabsModAttribute(string name)
        {
            Name = name;
            Version = "1.0";
            Author = "";
        }
    }

    /// <summary>
    /// Base class for every mod. Compile a class that derives from it (parameterless
    /// constructor) and drop the DLL in the Mods folder.
    /// </summary>
    public abstract class TabsMod
    {
        /// <summary>Called once, on the Unity main thread, when the loader starts.</summary>
        public abstract void Load(ModContext context);

        /// <summary>Called when the game quits. Optional.</summary>
        public virtual void Unload()
        {
        }
    }

    /// <summary>
    /// Per-mod handle: where the mod lives, a writable data folder, logging and
    /// per-frame callbacks.
    /// </summary>
    public sealed class ModContext
    {
        private readonly List<System.Action> _updateCallbacks = new List<System.Action>();

        internal ModContext(string name, string directory, string dataDirectory)
        {
            Name = name;
            Directory = directory;
            DataDirectory = dataDirectory;
        }

        /// <summary>Name from <see cref="TabsModAttribute"/> (or the class name).</summary>
        public string Name { get; internal set; }

        /// <summary>Folder the mod DLL was loaded from.</summary>
        public string Directory { get; internal set; }

        /// <summary>Writable folder for configs/saves (%LOCALAPPDATA%\TabsModLoader\&lt;mod&gt;).</summary>
        public string DataDirectory { get; internal set; }

        internal List<System.Action> UpdateCallbacks
        {
            get { return _updateCallbacks; }
        }

        /// <summary>
        /// Runs <paramref name="callback"/> every Unity Update, on the main thread.
        /// Exceptions thrown by the callback are logged and the callback is kept alive.
        /// </summary>
        public void OnUpdate(System.Action callback)
        {
            if (callback == null) return;
            _updateCallbacks.Add(callback);
            ModEngine.RegisterUpdate(Name, callback);
        }

        /// <summary>
        /// Runs <paramref name="callback"/> whenever the game applies damage to a unit,
        /// with the real contact position and weapon name (needs the patched game assembly).
        /// </summary>
        public void OnUnitDamaged(Action<UnitDamaged> callback)
        {
            GameHooks.OnUnitDamaged(callback);
        }

        public void Log(string message)
        {
            LoaderLog.Info("[" + Name + "] " + message);
        }

        public void LogWarning(string message)
        {
            LoaderLog.Warn("[" + Name + "] " + message);
        }

        public void LogError(string message)
        {
            LoaderLog.Error("[" + Name + "] " + message);
        }

        public void LogException(System.Exception exception)
        {
            LoaderLog.Error("[" + Name + "] unhandled exception", exception);
        }

        public void UnloadMod()
        {
            try { LoaderLog.Info("[" + Name + "] shutting down."); }
            catch (Exception) { }
        }
    }

    /// <summary>
    /// Public helpers for mods that do not want an instance (logging, discovery info).
    /// </summary>
    public static class Mods
    {
        /// <summary>Game root folder (the one holding the .exe).</summary>
        public static string GameDirectory
        {
            get { return ModLoaderCore.GameDirectory; }
        }

        /// <summary>Folder scanned for mod DLLs.</summary>
        public static string ModsDirectory
        {
            get { return ModLoaderCore.ModsDirectory; }
        }

        public static string LoaderVersion
        {
            get { return ModLoaderCore.Version; }
        }

        /// <summary>Runs a callback every frame without creating your own MonoBehaviour.</summary>
        public static void OnUpdate(System.Action callback)
        {
            ModEngine.RegisterUpdate("API", callback);
        }

        /// <summary>Runs a callback whenever the game applies damage to a unit.</summary>
        public static void OnUnitDamaged(Action<UnitDamaged> callback)
        {
            GameHooks.OnUnitDamaged(callback);
        }

        public static void Log(string message)
        {
            LoaderLog.Info(message);
        }

        public static void LogWarning(string message)
        {
            LoaderLog.Warn(message);
        }

        public static void LogError(string message)
        {
            LoaderLog.Error(message);
        }

        public static void LogException(System.Exception exception)
        {
            LoaderLog.Error("unhandled exception", exception);
        }
    }

    internal static class ModPaths
    {
        /// <summary>%LOCALAPPDATA%\TabsModLoader (always writable, unlike Program Files).</summary>
        public static string Root
        {
            get
            {
                string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                return Path.Combine(Path.Combine(local, "TabsModLoader"), string.Empty).TrimEnd('\\');
            }
        }

        public static string EnsureDirectory(string path)
        {
            try
            {
                if (!System.IO.Directory.Exists(path)) System.IO.Directory.CreateDirectory(path);
                return path;
            }
            catch (Exception)
            {
                return path;
            }
        }

        public static string Sanitize(string name)
        {
            if (string.IsNullOrEmpty(name)) return "mod";
            char[] invalid = Path.GetInvalidFileNameChars();
            var chars = name.ToCharArray();
            for (int i = 0; i < chars.Length; i++)
            {
                for (int j = 0; j < invalid.Length; j++)
                {
                    if (chars[i] == invalid[j]) { chars[i] = '_'; break; }
                }
            }
            return new string(chars).Trim();
        }
    }

    internal static class LoaderLog
    {
        private static readonly object Sync = new object();
        private static StreamWriter _writer;

        public static string LogFilePath { get; private set; }

        public static void Open(string gameDirectory)
        {
            try
            {
                string file = Path.Combine(gameDirectory, "TabsModLoader.log");
                if (!TryOpen(file)) { }
            }
            catch (System.Exception)
            {
            }

            if (_writer == null)
            {
                try
                {
                    string fallback = Path.Combine(ModPaths.EnsureDirectory(ModPaths.Root), "loader.log");
                    TryOpen(fallback);
                }
                catch (Exception)
                {
                }
            }
        }

        private static bool TryOpen(string path)
        {
            try
            {
                var writer = new StreamWriter(path, false);
                writer.AutoFlush = true;
                _writer = writer;
                LogFilePath = path;
                return true;
            }
            catch (System.Exception)
            {
                return false;
            }
        }

        public static void Info(string message)
        {
            Write("INFO", message, null);
        }

        public static void Warn(string message)
        {
            Write("WARN", message, null);
        }

        public static void Error(string message, System.Exception exception)
        {
            Write("ERROR", message, exception);
        }

        public static void Error(string message)
        {
            Write("ERROR", message, null);
        }

        private static void Write(string level, string message, System.Exception exception)
        {
            string line = "[" + DateTime.Now.ToString("HH:mm:ss.fff") + "] [" + level + "] " + message;
            if (exception != null) line += Environment.NewLine + exception;

            lock (Sync)
            {
                if (_writer != null)
                {
                    try
                    {
                        _writer.WriteLine(line);
                    }
                    catch (Exception)
                    {
                        _writer = null;
                    }
                }
            }

            // Mirror everything on the console window that opens next to the game.
            try
            {
                if (level == "ERROR") ConsoleWindow.WriteLine(line, ConsoleWindow.Red);
                else if (level == "WARN") ConsoleWindow.WriteLine(line, ConsoleWindow.Yellow);
                else ConsoleWindow.WriteLine(line, ConsoleWindow.Gray);
            }
            catch (System.Exception)
            {
            }

            try
            {
                if (level == "ERROR") UnityEngine.Debug.LogError("[TabsModLoader] " + message);
                else if (level == "WARN") UnityEngine.Debug.LogWarning("[TabsModLoader] " + message);
                else UnityEngine.Debug.Log("[TabsModLoader] " + message);
            }
            catch (System.Exception)
            {
                // Unity console unavailable (very early call), the log file still has it.
            }
        }

        public static void Close()
        {
            ModLoaderCore.Shutdown();
            ConsoleWindow.Close(false);

            lock (Sync)
            {
                if (_writer == null) return;
                try
                {
                    _writer.Flush();
                    _writer.Close();
                }
                catch (System.Exception)
                {
                }
                _writer = null;
            }
        }
    }
}
