using System;
using UnityEngine;

namespace TabsModLoader
{
    /// <summary>
    /// Entry point called from the patched <c>GameLogic.Awake()</c>.
    /// Runs once on the Unity main thread with the engine fully initialized.
    /// </summary>
    public static class Bootstrap
    {
        private static bool _initialized;

        public static void Init()
        {
            if (_initialized) return;
            _initialized = true;

            try
            {
                // Mods that animate effects need frames even while the window is unfocused.
                Application.runInBackground = true;

                ModLoaderCore.Prepare();

                var host = new GameObject("TabsModLoader");
                UnityEngine.Object.DontDestroyOnLoad(host);
                host.hideFlags = HideFlags.HideAndDontSave;
                ModEngine.Instance = host.AddComponent<ModEngine>();

                ModLoaderCore.LoadAll();
            }
            catch (Exception e)
            {
                LoaderLog.Error("TabsModLoader bootstrap failed", e);
            }
        }
    }
}
