using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using UnityEngine;

namespace TabsModLoader
{
    /// <summary>A mod instance together with its context.</summary>
    public sealed class LoadedMod
    {
        internal LoadedMod(ModContext context, TabsMod instance, string version, string author, string assemblyPath)
        {
            Context = context;
            Instance = instance;
            Version = version;
            Author = author;
            AssemblyPath = assemblyPath;
        }

        public ModContext Context { get; private set; }
        public TabsMod Instance { get; private set; }

        /// <summary>Version from <see cref="TabsModAttribute"/>.</summary>
        public string Version { get; private set; }

        /// <summary>Author from <see cref="TabsModAttribute"/> (may be empty).</summary>
        public string Author { get; private set; }

        /// <summary>Full path of the DLL the mod came from.</summary>
        public string AssemblyPath { get; private set; }
    }

    /// <summary>Discovers and loads every TabsMod found in the Mods folder.</summary>
    public static class ModLoaderCore
    {
        public const string Version = "1.0.0";

        private static readonly List<string> _loadedAssemblyPaths = new List<string>();
        private static bool _pathsReady;

        public static string GameDirectory { get; private set; }
        public static string ModsDirectory { get; private set; }
        public static readonly List<LoadedMod> LoadedMods = new List<LoadedMod>();

        /// <summary>
        /// Resolves the game folders and opens the log. Safe to call from the patched
        /// Unity method (main thread, Unity already initialized).
        /// </summary>
        internal static void Prepare()
        {
            if (_pathsReady) return;
            _pathsReady = true;

            try
            {
                string dataPath = Application.dataPath;
                dataPath = dataPath.TrimEnd('/', '\\');
                GameDirectory = Path.GetDirectoryName(dataPath);
            }
            catch (Exception)
            {
                GameDirectory = AppDomain.CurrentDomain.BaseDirectory.TrimEnd('/', '\\');
            }

            ModsDirectory = Path.Combine(GameDirectory, "Mods");
            LoaderLog.Open(GameDirectory);
            ConsoleWindow.Open("TabsModLoader v" + Version);
            ConsoleWindow.WriteLine("  ================================================================", ConsoleWindow.Cyan);
            ConsoleWindow.WriteLine("   TabsModLoader v" + Version + "  -  Totally Accurate Battle Simulator", ConsoleWindow.Cyan);
            ConsoleWindow.WriteLine("  ================================================================", ConsoleWindow.Cyan);
            ConsoleWindow.WriteLine(string.Empty);
            ConsoleWindow.WriteLine("  Unity   : " + SafeUnityVersion(), ConsoleWindow.Gray);
            ConsoleWindow.WriteLine("  Jogo    : " + GameDirectory, ConsoleWindow.Gray);

            LoaderLog.Info("TabsModLoader v" + Version + " starting (Unity " + SafeUnityVersion() + ", game folder: " + GameDirectory + ")");
            LoaderLog.Info("Log file: " + LoaderLog.LogFilePath);
            ConsoleWindow.WriteLine(string.Empty);
            ConsoleWindow.WriteLine("  > Mods folder: " + ModsDirectory, ConsoleWindow.Cyan);
            ConsoleWindow.WriteLine(string.Empty);
            LoaderLog.Info(ConsoleWindow.IsOpen
                ? "Console window opened for loader output."
                : "Could not allocate a console window; output goes to the log file only.");

            AppDomain.CurrentDomain.AssemblyResolve += ResolveAssembly;
        }

        private static string SafeUnityVersion()
        {
            try
            {
                return Application.unityVersion;
            }
            catch (Exception)
            {
                return "unknown";
            }
        }

        internal static void LoadAll()
        {
            string[] files;
            try
            {
                if (!Directory.Exists(ModsDirectory))
                {
                    Directory.CreateDirectory(ModsDirectory);
                    LoaderLog.Info("Mods folder was missing, created: " + ModsDirectory);
                    return;
                }
                files = Directory.GetFiles(ModsDirectory, "*.dll", SearchOption.AllDirectories);
            }
            catch (Exception e)
            {
                LoaderLog.Error("Could not scan " + ModsDirectory, e);
                return;
            }

            Array.Sort(files, StringComparer.OrdinalIgnoreCase);
            if (files.Length == 0)
            {
                LoaderLog.Info("No mods found in " + ModsDirectory);
                ConsoleWindow.WriteLine("  Nenhum mod encontrado. Coloque DLLs em: " + ModsDirectory, ConsoleWindow.Yellow);
                ConsoleWindow.WriteLine(string.Empty);
                return;
            }

            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < files.Length; i++)
            {
                string file = files[i];
                string name = Path.GetFileNameWithoutExtension(file);
                if (!seen.Add(name)) continue;
                if (string.Equals(name, "TabsModLoader", StringComparison.OrdinalIgnoreCase)) continue;
                if (string.Equals(name, "Mono.Cecil", StringComparison.OrdinalIgnoreCase)) continue;
                LoadAssembly(file);
            }

            LoaderLog.Info("Finished: " + LoadedMods.Count + " mod(s) loaded.");
            PrintSummary();
        }

        /// <summary>Prints the loaded-mod table on the console window.</summary>
        private static void PrintSummary()
        {
            if (!ConsoleWindow.IsOpen) return;

            ConsoleWindow.WriteLine(string.Empty);
            if (LoadedMods.Count == 0)
            {
                ConsoleWindow.WriteLine("  Nenhum mod carregado.", ConsoleWindow.Yellow);
            }
            else
            {
                ConsoleWindow.WriteLine("  Mods carregados (" + LoadedMods.Count + "):", ConsoleWindow.Green);
                for (int i = 0; i < LoadedMods.Count; i++)
                {
                    LoadedMod mod = LoadedMods[i];
                    if (mod == null || mod.Context == null) continue;

                    string author = string.IsNullOrEmpty(mod.Author) ? "desconhecido" : mod.Author;
                    ConsoleWindow.WriteLine("    [" + (i + 1) + "] " + mod.Context.Name + "  v" + mod.Version +
                                           "  por " + author, ConsoleWindow.White);
                    ConsoleWindow.WriteLine("        arquivo : " + mod.AssemblyPath);
                    ConsoleWindow.WriteLine("        dados   : " + mod.Context.DataDirectory);
                    ConsoleWindow.WriteLine("        classe  : " + (mod.Instance != null ? mod.Instance.GetType().FullName : "?"));
                }
            }
            ConsoleWindow.WriteLine(string.Empty);
            ConsoleWindow.WriteLine("  Log completo: " + LoaderLog.LogFilePath, ConsoleWindow.DarkGray);
            ConsoleWindow.WriteLine("  ----------------------------------------------------------------", ConsoleWindow.DarkGray);
            ConsoleWindow.WriteLine(string.Empty);
        }

        /// <summary>Called by the loader right before the process exits.</summary>
        internal static void Shutdown()
        {
            ConsoleWindow.WriteLine("  TabsModLoader encerrando.", ConsoleWindow.DarkGray);
        }

        private static void LoadAssembly(string path)
        {
            Assembly assembly;
            try
            {
                assembly = Assembly.LoadFrom(path);
                _loadedAssemblyPaths.Add(path);
            }
            catch (Exception e)
            {
                LoaderLog.Error("Failed to load assembly " + path, e);
                return;
            }

            Type[] types;
            try
            {
                types = assembly.GetTypes();
            }
            catch (ReflectionTypeLoadException e)
            {
                types = e.Types;
                LoaderLog.Warn("Some types of " + Path.GetFileName(path) + " could not be inspected: " + e.Message);
            }
            catch (Exception e)
            {
                LoaderLog.Error("Failed to enumerate types of " + path, e);
                return;
            }

            int found = 0;
            for (int i = 0; i < types.Length; i++)
            {
                Type type = types[i];
                if (type == null || !type.IsClass || type.IsAbstract) continue;
                if (!typeof(TabsMod).IsAssignableFrom(type)) continue;
                found++;
                StartMod(type, path);
            }

            if (found == 0)
            {
                LoaderLog.Warn("No class deriving from TabsMod found in " + Path.GetFileName(path));
            }
        }

        private static void StartMod(Type type, string assemblyPath)
        {
            string fallbackName = type.FullName;
            string displayName = fallbackName;
            string version = "1.0";
            string author = "";

            var attribute = (TabsModAttribute)Attribute.GetCustomAttribute(type, typeof(TabsModAttribute));
            if (attribute != null)
            {
                if (!string.IsNullOrEmpty(attribute.Name)) displayName = attribute.Name;
                version = attribute.Version;
                author = attribute.Author;
            }

            string modDirectory = Path.GetDirectoryName(assemblyPath);
            string dataDirectory = Path.Combine(ModPaths.Root, ModPaths.Sanitize(displayName));
            ModPaths.EnsureDirectory(dataDirectory);

            var context = new ModContext(displayName, modDirectory, dataDirectory);

            TabsMod instance;
            try
            {
                instance = (TabsMod)Activator.CreateInstance(type);
            }
            catch (Exception e)
            {
                LoaderLog.Error("Could not create mod instance " + type.FullName, e);
                return;
            }

            LoaderLog.Info("Loading mod '" + displayName + "' v" + version + (string.IsNullOrEmpty(author) ? "" : " by " + author) +
                           " (" + type.FullName + " from " + Path.GetFileName(assemblyPath) + ")");

            try
            {
                instance.Load(context);
            }
            catch (Exception e)
            {
                LoaderLog.Error("Mod '" + displayName + "' threw while loading; it stays in the list but may be broken.", e);
            }

            LoadedMods.Add(new LoadedMod(context, instance, version, author, assemblyPath));
            ConsoleWindow.WriteLine("  + carregado: " + displayName + " v" + version +
                                   (string.IsNullOrEmpty(author) ? "" : " por " + author), ConsoleWindow.Green);
        }

        private static Assembly ResolveAssembly(object sender, ResolveEventArgs args)
        {
            string simpleName;
            try
            {
                simpleName = new AssemblyName(args.Name).Name;
            }
            catch (Exception)
            {
                return null;
            }
            if (string.IsNullOrEmpty(simpleName)) return null;

            // Old Unity mscorlib (NET 3.5) has no ResolveEventArgs.RequestingAssembly,
            // so probe the mod folders we already know about instead.
            TryAddDirectories(ModsDirectory);

            for (int i = 0; i < _loadedAssemblyPaths.Count; i++)
            {
                string dir = Path.GetDirectoryName(_loadedAssemblyPaths[i]);
                Assembly resolved = TryLoad(simpleName, dir);
                if (resolved != null) return resolved;
            }
            return null;
        }

        private static void TryAddDirectories(string directory)
        {
            if (string.IsNullOrEmpty(directory) || !Directory.Exists(directory)) return;
            string candidate = Path.Combine(directory, "TabsModLoader.runtimeconfig");
            GC.KeepAlive(candidate);
        }

        private static Assembly TryLoad(string simpleName, string directory)
        {
            if (string.IsNullOrEmpty(directory)) return null;
            try
            {
                string candidate = Path.Combine(directory, simpleName + ".dll");
                if (File.Exists(candidate)) return Assembly.LoadFrom(candidate);
            }
            catch (Exception)
            {
            }
            return null;
        }
    }
}
