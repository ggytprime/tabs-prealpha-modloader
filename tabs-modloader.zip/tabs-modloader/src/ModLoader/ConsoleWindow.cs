using System;
using System.Runtime.InteropServices;
using System.Text;

namespace TabsModLoader
{
    /// <summary>
    /// Opens a real Win32 console window next to the game so the loader can show
    /// what it is doing: version, folders, which mods were found/loaded and errors.
    /// Unity players have no console of their own, so we allocate one.
    /// The game's old Mono mscorlib has no Console.ForegroundColor, so colours go
    /// through kernel32 directly.
    /// </summary>
    internal static class ConsoleWindow
    {
        private const int StdOutputHandle = -11;

        // Console text attributes (FOREGROUND_* | BACKGROUND_*)
        internal const short Gray = 7;
        internal const short White = 15;
        internal const short Green = 10;
        internal const short Red = 12;
        internal const short Yellow = 14;
        internal const short Cyan = 11;
        internal const short DarkGray = 8;

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool AllocConsole();

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool FreeConsole();

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern bool SetConsoleTitle(string title);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr GetStdHandle(int nStdHandle);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool SetConsoleTextAttribute(IntPtr hConsoleOutput, short attributes);

        private static bool _tried;
        private static bool _open;

        internal static bool IsOpen
        {
            get { return _open; }
        }

        /// <summary>Allocates the console once. Returns true when output is going to it.</summary>
        internal static bool Open(string title)
        {
            if (_tried) return _open;
            _tried = true;

            try
            {
                _open = AllocConsole();
            }
            catch (Exception)
            {
                _open = false;
            }

            if (!_open) return false;

            try
            {
                SetConsoleTitle(title);
            }
            catch (Exception)
            {
            }

            try
            {
                Console.OutputEncoding = Encoding.UTF8;
            }
            catch (Exception)
            {
            }

            return true;
        }

        private static void SetColor(short attributes)
        {
            try
            {
                SetConsoleTextAttribute(GetStdHandle(StdOutputHandle), attributes);
            }
            catch (Exception)
            {
            }
        }

        internal static void WriteLine(string text)
        {
            WriteLine(text, Gray);
        }

        internal static void WriteLine(string text, short attributes)
        {
            if (!_open) return;
            try
            {
                SetColor(attributes);
                Console.WriteLine(text);
                SetColor(Gray);
            }
            catch (Exception)
            {
                _open = false;
            }
        }

        /// <summary>Keeps the window open when the game crashes/exits quickly, so the last lines stay readable.</summary>
        internal static void Close(bool keepVisible)
        {
            if (!_open) return;

            if (keepVisible)
            {
                try
                {
                    Console.WriteLine();
                    SetColor(DarkGray);
                    Console.WriteLine("Pressione Enter para fechar esta janela...");
                    SetColor(Gray);
                    Console.ReadLine();
                }
                catch (Exception)
                {
                }
            }

            try
            {
                FreeConsole();
            }
            catch (Exception)
            {
            }
            _open = false;
        }
    }
}
