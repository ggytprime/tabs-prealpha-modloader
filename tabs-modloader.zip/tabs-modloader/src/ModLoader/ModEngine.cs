using System;
using System.Collections.Generic;
using UnityEngine;

namespace TabsModLoader
{
    /// <summary>
    /// Hidden object that keeps the loader alive across scene loads and drives the
    /// per-frame callbacks registered by mods.
    /// </summary>
    public sealed class ModEngine : MonoBehaviour
    {
        private struct Entry
        {
            public string Owner;
            public System.Action Callback;
        }

        private readonly List<Entry> _entries = new List<Entry>();
        private Entry[] _snapshot;

        internal static ModEngine Instance { get; set; }

        public static void RegisterUpdate(string owner, System.Action callback)
        {
            ModEngine engine = Instance;
            if (engine == null)
            {
                LoaderLog.Error("Cannot register an Update callback for '" + owner + "': loader engine is not running.", null);
                return;
            }
            engine._entries.Add(new Entry { Owner = owner, Callback = callback });
            engine._snapshot = null;
        }

        private Entry[] Snapshot()
        {
            if (_snapshot == null || _snapshot.Length != _entries.Count)
            {
                _snapshot = _entries.ToArray();
            }
            return _snapshot;
        }

        private static bool _tickReported;

        private void Update()
        {
            Entry[] callbacks = Snapshot();

            if (!_tickReported)
            {
                _tickReported = true;
                LoaderLog.Info("Loader engine is ticking (" + callbacks.Length + " update callback(s) attached).");
            }
            for (int i = 0; i < callbacks.Length; i++)
            {
                try
                {
                    callbacks[i].Callback();
                }
                catch (System.Exception e)
                {
                    LoaderLog.Error("Update callback from '" + callbacks[i].Owner + "' threw; it was removed.", e);
                    _entries.Remove(callbacks[i]);
                    _snapshot = null;
                }
            }
        }

        private void OnApplicationQuit()
        {
            LoaderLog.Info("Game is quitting, unloading " + ModLoaderCore.LoadedMods.Count + " mod(s).");
            foreach (LoadedMod mod in ModLoaderCore.LoadedMods)
            {
                if (mod == null || mod.Context == null) continue;
                try
                {
                    mod.Context.UnloadMod();
                    if (mod.Instance != null) mod.Instance.Unload();
                }
                catch (System.Exception e)
                {
                    LoaderLog.Error("Unload of '" + mod.Context.Name + "' failed", e);
                }
            }
            LoaderLog.Close();
        }
    }
}
