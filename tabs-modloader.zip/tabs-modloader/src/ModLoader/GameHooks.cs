using System;
using System.Collections.Generic;
using UnityEngine;

namespace TabsModLoader
{
    /// <summary>
    /// One damage event coming straight from the game's <c>UnitHandler.TakeDamage</c>.
    /// </summary>
    public struct UnitDamaged
    {
        /// <summary>Unit that received the damage.</summary>
        public UnitHandler Unit;

        /// <summary>Damage amount the game was about to apply.</summary>
        public float Damage;

        /// <summary>Direction the game passed along with the hit (may be Vector3.zero).</summary>
        public Vector3 Direction;

        /// <summary>Weapon name reported by the game: "club", "sword", "spear", "physical", "explosive", ...</summary>
        public string Weapon;

        /// <summary>World position of the contact point, when the game knows it.</summary>
        public Vector3 Position;
    }

    /// <summary>
    /// Hooks injected in the game assembly by Patcher.exe. A mod never calls these; it
    /// subscribes through <c>ctx.OnUnitDamaged(...)</c>.
    /// </summary>
    public static class GameHooks
    {
        private static readonly List<Action<UnitDamaged>> Handlers = new List<Action<UnitDamaged>>();
        private static Action<UnitDamaged>[] _snapshot;
        private static int _depth;

        public static void OnUnitDamaged(Action<UnitDamaged> handler)
        {
            if (handler == null) return;
            Handlers.Add(handler);
            _snapshot = null;
        }

        /// <summary>
        /// Hook target: the patched <c>UnitHandler.TakeDamage()</c> calls this right before it
        /// subtracts health, so <c>Unit.Health</c> is still the pre-hit value here.
        /// </summary>
        public static void UnitDamage(UnitHandler unit, float damage, Vector3 direction, string weapon, Vector3 position)
        {
            if (Handlers.Count == 0) return;
            if (_depth > 0) return;

            _depth++;
            try
            {
                if (_snapshot == null) _snapshot = Handlers.ToArray();
                Action<UnitDamaged>[] handlers = _snapshot;

                var e = new UnitDamaged
                {
                    Unit = unit,
                    Damage = damage,
                    Direction = direction,
                    Weapon = weapon,
                    Position = position
                };

                for (int i = 0; i < handlers.Length; i++)
                {
                    try
                    {
                        handlers[i](e);
                    }
                    catch (Exception ex)
                    {
                        Handlers.Remove(handlers[i]);
                        _snapshot = null;
                        LoaderLog.Error("A UnitDamaged handler threw; it was removed.", ex);
                    }
                }
            }
            finally
            {
                _depth--;
            }
        }
    }
}
