using System;
using System.IO;
using TabsModLoader;

namespace Example
{
    /// <summary>
    /// Minimal example mod. Compile against TabsModLoader.dll and drop the DLL into
    /// the game's Mods folder. It only uses the loader API, so it is a good starting
    /// point to copy when writing your own mod.
    /// </summary>
    [TabsMod("Example Mod", Version = "1.0.0", Author = "voce")]
    public class ExampleMod : TabsMod
    {
        private int _frames;

        public override void Load(ModContext ctx)
        {
            ctx.Log("Example Mod loaded from " + ctx.Directory);
            ctx.Log("Data folder: " + ctx.DataDirectory);

            // Runs every Unity frame, on the main thread.
            ctx.OnUpdate(delegate
            {
                _frames++;
                if (_frames == 120)
                {
                    ctx.Log("Still alive after " + _frames + " frames - mod update callback works.");

                    try
                    {
                        string marker = Path.Combine(ctx.DataDirectory, "loaded.txt");
                        File.WriteAllText(marker, "ExampleMod ran " + _frames + " frames.\r\n");
                        ctx.Log("Wrote " + marker);
                    }
                    catch (Exception e)
                    {
                        ctx.LogException(e);
                    }
                }
            });
        }

        public override void Unload()
        {
            LoaderLogWrite();
        }

        private static void LoaderLogWrite()
        {
            Mods.Log("Example Mod unloaded.");
        }
    }
}
