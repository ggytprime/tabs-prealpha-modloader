using System;
using UnityEngine;

namespace Gore
{
    /// <summary>
    /// Materials, procedural textures and primitive helpers for the gore effects.
    ///
    /// Unity 5.5 ships the Standard shader with the game, so instead of shipping shader
    /// assets the mod builds "wet blood" materials at runtime: dark red albedo, high
    /// smoothness (the shiny layer a fresh splat has), no metallic, plus a noisy albedo
    /// texture so droplets and chunks never look like flat plastic.
    /// </summary>
    internal static class GoreMaterials
    {
        private static bool _ready;

        private static Material _freshBlood;
        private static Material _darkBlood;
        private static Material _bone;
        private static Material _meat;
        private static Material[] _splats;

        internal static Material FreshBlood { get { Ensure(); return _freshBlood; } }
        internal static Material DarkBlood { get { Ensure(); return _darkBlood; } }
        internal static Material Bone { get { Ensure(); return _bone; } }
        internal static Material Meat { get { Ensure(); return _meat; } }

        /// <summary>Random floor-splat material (several baked variants so no two look alike).</summary>
        internal static Material SplatDecal
        {
            get
            {
                Ensure();
                if (_splats == null || _splats.Length == 0) return _darkBlood;
                return _splats[UnityEngine.Random.Range(0, _splats.Length)];
            }
        }

        private static Shader FindStandard()
        {
            Shader shader = Shader.Find("Standard");
            if (shader == null) shader = Shader.Find("Legacy Shaders/Diffuse");
            return shader;
        }

        private static void Ensure()
        {
            if (_ready) return;
            _ready = true;

            try
            {
                Shader shader = FindStandard();
                if (shader == null) return;

                Texture2D bloodTex = NoiseTexture(64, new Color(0.45f, 0.02f, 0.02f), new Color(0.18f, 0f, 0f));
                Texture2D boneTex = NoiseTexture(48, new Color(0.93f, 0.9f, 0.79f), new Color(0.72f, 0.68f, 0.55f));
                Texture2D meatTex = NoiseTexture(48, new Color(0.62f, 0.08f, 0.08f), new Color(0.3f, 0.02f, 0.02f));
                _splats = new Material[4];

                _freshBlood = WetMaterial(shader, new Color(0.52f, 0.02f, 0.02f), bloodTex, 0.88f);
                _darkBlood = WetMaterial(shader, new Color(0.24f, 0.005f, 0.005f), bloodTex, 0.72f);
                _bone = WetMaterial(shader, new Color(0.95f, 0.92f, 0.82f), boneTex, 0.28f);
                _meat = WetMaterial(shader, new Color(0.66f, 0.09f, 0.08f), meatTex, 0.8f);

                // The floor splats need alpha blending, so switch Standard into fade mode.
                for (int i = 0; i < _splats.Length; i++)
                {
                    Material splat = new Material(shader);
                    splat.mainTexture = SplatTexture(128);
                    splat.color = new Color(0.55f, 0.02f, 0.02f, 1f);
                    MakeTransparent(splat);
                    _splats[i] = splat;
                }
            }
            catch (Exception)
            {
                _ready = false;
            }
        }

        private static Material WetMaterial(Shader shader, Color color, Texture texture, float smoothness)
        {
            Material material = new Material(shader);
            material.color = color;
            material.mainTexture = texture;

            if (material.HasProperty("_Glossiness")) material.SetFloat("_Glossiness", smoothness);
            if (material.HasProperty("_Metallic")) material.SetFloat("_Metallic", 0f);
            if (material.HasProperty("_SpecularHighlights")) material.SetFloat("_SpecularHighlights", 1f);

            return material;
        }

        /// <summary>Turns a Standard material into an alpha-blended one (Unity 5.5 recipe).</summary>
        private static void MakeTransparent(Material material)
        {
            material.SetFloat("_Mode", 3f);
            material.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
            material.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
            material.SetInt("_ZWrite", 0);
            material.DisableKeyword("_ALPHATEST_ON");
            material.EnableKeyword("_ALPHABLEND_ON");
            material.DisableKeyword("_ALPHAPREMULTIPLY_ON");
            material.renderQueue = 3000;
        }

        /// <summary>Small mottled texture so surfaces are not a single flat colour.</summary>
        private static Texture2D NoiseTexture(int size, Color bright, Color dark)
        {
            var texture = new Texture2D(size, size, TextureFormat.RGBA32, true);
            var pixels = new Color[size * size];

            float seed = UnityEngine.Random.Range(0f, 100f);

            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float n = Mathf.PerlinNoise(seed + x * 0.35f, seed + y * 0.35f);
                    float n2 = Mathf.PerlinNoise(seed * 2f + x * 1.1f, seed * 2f + y * 1.1f);
                    float t = Mathf.Clamp01(n * 0.75f + n2 * 0.35f - 0.05f);
                    pixels[y * size + x] = Color.Lerp(dark, bright, t);
                }
            }

            texture.SetPixels(pixels);
            texture.wrapMode = TextureWrapMode.Repeat;
            texture.Apply(true);
            return texture;
        }

        /// <summary>
        /// Blood splat mask: a few overlapping blobs plus satellite droplets, which reads much
        /// better on the floor than a plain circle does.
        /// </summary>
        private static Texture2D SplatTexture(int size)
        {
            var texture = new Texture2D(size, size, TextureFormat.RGBA32, true);
            var pixels = new Color[size * size];

            int blobs = UnityEngine.Random.Range(4, 8);
            var centers = new Vector2[blobs];
            var radii = new float[blobs];

            for (int i = 0; i < blobs; i++)
            {
                centers[i] = new Vector2(
                    size * (0.5f + UnityEngine.Random.Range(-0.18f, 0.18f)),
                    size * (0.5f + UnityEngine.Random.Range(-0.18f, 0.18f)));
                radii[i] = size * UnityEngine.Random.Range(0.16f, 0.3f);
            }

            float seed = UnityEngine.Random.Range(0f, 50f);

            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float alpha = 0f;

                    for (int i = 0; i < blobs; i++)
                    {
                        float dx = x - centers[i].x;
                        float dy = y - centers[i].y;
                        float distance = Mathf.Sqrt(dx * dx + dy * dy);

                        // Wobbly border instead of a perfect circle.
                        float wobble = Mathf.PerlinNoise(
                            seed + Mathf.Atan2(dy, dx) * 2.2f,
                            seed + distance * 0.09f) * 0.45f + 0.75f;

                        float edge = radii[i] * wobble;
                        if (distance < edge)
                            alpha = Mathf.Max(alpha, Mathf.Clamp01((edge - distance) / (size * 0.08f)));
                    }

                    // Speckles around the main puddle.
                    float grain = Mathf.PerlinNoise(seed + x * 0.5f, seed + y * 0.5f);
                    if (alpha < 0.05f && grain > 0.78f) alpha = 0.35f;

                    float shade = 0.65f + 0.35f * Mathf.PerlinNoise(seed + x * 0.3f, seed + y * 0.3f);
                    pixels[y * size + x] = new Color(shade, shade, shade, alpha);
                }
            }

            texture.SetPixels(pixels);
            texture.wrapMode = TextureWrapMode.Clamp;
            texture.Apply(true);
            return texture;
        }

        // ---------------------------------------------------------------- primitives

        internal static GameObject Primitive(PrimitiveType type, Transform parent, string name)
        {
            GameObject go = GameObject.CreatePrimitive(type);
            go.name = name;

            Collider collider = go.GetComponent<Collider>();
            if (collider != null) UnityEngine.Object.Destroy(collider);

            if (parent != null) go.transform.SetParent(parent, true);
            return go;
        }

        internal static void SetMaterial(GameObject go, Material material)
        {
            if (go == null || material == null) return;

            Renderer renderer = go.GetComponent<Renderer>();
            if (renderer != null) renderer.sharedMaterial = material;
        }
    }
}
