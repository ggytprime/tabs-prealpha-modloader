using System;
using System.Collections.Generic;
using TabsModLoader;
using UnityEngine;

namespace Gore
{
    /// <summary>
    /// Real dismemberment built on the game's own ragdoll: every limb is a body part held by
    /// a Joint, so destroying the joint closest to the hit point tears that limb off. The stump
    /// gets an exposed bone and keeps bleeding for a few seconds.
    /// </summary>
    internal static class Dismemberment
    {
        private const int MaxSeverPerUnit = 4;
        private const int MaxBones = 70;
        private const float SeverReach = 1.1f;
        private const float BleedSeconds = 6f;

        private sealed class BleedingLimb
        {
            public Rigidbody Body;
            public float TimeLeft;
            public float DripTimer;
            public Vector3 Anchor;
            public float Reach;
        }

        private sealed class LooseLimb
        {
            public Rigidbody Body;
            public float SettleTimer;
            public float Age;
            public bool Settled;
        }

        private static readonly Dictionary<int, int> _severCount = new Dictionary<int, int>();
        private static readonly List<BleedingLimb> _bleeding = new List<BleedingLimb>();
        private static readonly List<LooseLimb> _loose = new List<LooseLimb>();
        private static readonly List<GameObject> _bones = new List<GameObject>();

        internal static int SeveredTotal { get; private set; }

        /// <summary>Tears off the limb closest to <paramref name="hitPoint"/>. Returns false when nothing was severed.</summary>
        internal static bool TrySever(UnitHandler unit, Vector3 hitPoint, Vector3 direction, float damage, string weapon, ModContext ctx)
        {
            if (unit == null) return false;

            int id;
            try
            {
                id = unit.GetInstanceID();
            }
            catch (Exception)
            {
                return false;
            }

            int already;
            _severCount.TryGetValue(id, out already);
            if (already >= MaxSeverPerUnit) return false;

            Joint victim = null;
            Rigidbody limb = null;
            Rigidbody body = null;
            float bestDistance = float.MaxValue;

            try
            {
                Joint[] joints = unit.GetComponentsInChildren<Joint>();
                for (int i = 0; i < joints.Length; i++)
                {
                    Joint joint = joints[i];
                    if (joint == null) continue;

                    Rigidbody a = joint.GetComponent<Rigidbody>();
                    Rigidbody b = joint.connectedBody;
                    if (a == null && b == null) continue;

                    Vector3 point = joint.transform.position;
                    if (b != null) point = (point + b.worldCenterOfMass) * 0.5f;

                    float distance = Vector3.Distance(point, hitPoint);
                    if (distance < bestDistance)
                    {
                        bestDistance = distance;
                        victim = joint;
                        limb = a;
                        body = b;
                    }
                }
            }
            catch (Exception e)
            {
                ctx.LogException(e);
                return false;
            }

            if (victim == null || bestDistance > SeverReach) return false;

            Vector3 anchor = victim.transform.position;

            // Bone axis: across the joint, so both stumps get a shard pointing outwards.
            Vector3 axis;
            if (limb != null && body != null)
                axis = (limb.worldCenterOfMass - body.worldCenterOfMass).normalized;
            else if (limb != null)
                axis = (limb.worldCenterOfMass - anchor).normalized;
            else
                axis = direction.sqrMagnitude > 0.001f ? direction.normalized : Vector3.up;

            if (axis.sqrMagnitude < 0.01f) axis = Vector3.up;

            Rigidbody falling = limb;
            if (limb != null && body != null)
            {
                // The piece farther from the unit root is the one that falls away.
                float dLimb = Vector3.Distance(limb.worldCenterOfMass, unit.transform.position);
                float dBody = Vector3.Distance(body.worldCenterOfMass, unit.transform.position);
                falling = dLimb >= dBody ? limb : body;
            }

            try
            {
                // Detach the piece COMPLETELY: any joint still referencing it (as owner or as
                // connectedBody) would keep dragging it and stretch the limb across the map.
                Joint[] allJoints = unit.GetComponentsInChildren<Joint>();
                for (int i = 0; i < allJoints.Length; i++)
                {
                    Joint joint = allJoints[i];
                    if (joint == null) continue;

                    Rigidbody own = joint.GetComponent<Rigidbody>();
                    bool touchesFalling = own == falling || joint.connectedBody == falling;
                    if (!touchesFalling) continue;

                    UnityEngine.Object.Destroy(joint);
                }
            }
            catch (Exception e)
            {
                ctx.LogException(e);
                return false;
            }

            _severCount[id] = already + 1;
            SeveredTotal++;

            // Turn the loose piece into a harmless chunk that just drops away from the body.
            if (falling != null)
            {
                try
                {
                    // No scaled parent: inherited scale is what makes detached ragdoll pieces
                    // jitter and stretch in Unity's physics.
                    falling.transform.SetParent(null, true);

                    falling.drag = 0.35f;
                    falling.angularDrag = 1.6f;
                    falling.maxAngularVelocity = 6f;

                    // A flying leg must stop being a weapon and stop damaging its old owner.
                    PhysicsDamageChecker[] checkers = falling.GetComponentsInChildren<PhysicsDamageChecker>();
                    for (int i = 0; i < checkers.Length; i++)
                        if (checkers[i] != null) checkers[i].enabled = false;

                    Bodypart[] bodyparts = falling.GetComponentsInChildren<Bodypart>();
                    for (int i = 0; i < bodyparts.Length; i++)
                        if (bodyparts[i] != null) bodyparts[i].enabled = false;

                    // Same layer the game gives to dead parts: it stops a flying leg from
                    // shoving living units around, but it still lands on the ground.
                    Collider[] looseColliders = falling.GetComponentsInChildren<Collider>();
                    for (int i = 0; i < looseColliders.Length; i++)
                        if (looseColliders[i] != null) looseColliders[i].gameObject.layer = 8;

                    Vector3 away = falling.worldCenterOfMass - unit.transform.position;
                    away = away.sqrMagnitude > 0.001f
                        ? away.normalized
                        : (direction.sqrMagnitude > 0.001f ? direction.normalized : Vector3.up);

                    // VelocityChange, not Impulse: impulse on a 0.2 kg limb used to launch it
                    // across the map. This is a gentle ~1.5 m/s push.
                    float push = Mathf.Clamp(0.8f + damage * 0.004f, 0.8f, 2.2f);
                    falling.AddForce((away * 0.7f + Vector3.up * 0.4f).normalized * push, ForceMode.VelocityChange);
                    falling.AddTorque(UnityEngine.Random.insideUnitSphere * 1.6f, ForceMode.VelocityChange);

                    _loose.Add(new LooseLimb { Body = falling, SettleTimer = 1.5f, Age = 0f });
                }
                catch (Exception)
                {
                }
            }

            // Exposed bone on both sides of the cut.
            SpawnBoneStub(limb, anchor, axis);
            SpawnBoneStub(body, anchor, -axis);

            BoneChips(anchor, direction);

            BloodSystem.SeverBurst(anchor, direction);
            BloodSystem.MeatChunk(anchor, direction, 1.1f);

            if (falling != null)
            {
                _bleeding.Add(new BleedingLimb
                {
                    Body = falling,
                    TimeLeft = BleedSeconds,
                    DripTimer = 0.12f,
                    Anchor = anchor,
                    Reach = 2.2f
                });
            }

            // The stump left on the body keeps gushing for a moment as well.
            Rigidbody stump = falling == limb ? body : limb;
            if (stump != null && stump != falling)
            {
                _bleeding.Add(new BleedingLimb
                {
                    Body = stump,
                    TimeLeft = BleedSeconds * 0.55f,
                    DripTimer = 0.08f,
                    Anchor = anchor,
                    Reach = 3f
                });
            }

            ctx.Log("Membro arrancado (dano " + Mathf.RoundToInt(damage) + ", golpe '" + (string.IsNullOrEmpty(weapon) ? "?" : weapon) + "').");
            return true;
        }

        /// <summary>Pokes a bone shard out of a body part that survived a heavy blunt hit.</summary>
        internal static void ExposeBone(Vector3 hitPoint, Vector3 direction, Transform part, ModContext ctx)
        {
            try
            {
                Vector3 axis = direction.sqrMagnitude > 0.001f ? direction.normalized : Vector3.up;
                SpawnBone(part, hitPoint, axis, 1.15f);
                BoneChips(hitPoint, direction);
            }
            catch (Exception e)
            {
                ctx.LogException(e);
            }
        }

        /// <summary>Nearest body part of the unit to a world point (used to parent exposed bones).</summary>
        internal static Transform NearestPart(UnitHandler unit, Vector3 point)
        {
            Transform best = null;
            float bestDistance = float.MaxValue;

            try
            {
                Rigidbody[] bodies = unit.GetComponentsInChildren<Rigidbody>();
                for (int i = 0; i < bodies.Length; i++)
                {
                    Rigidbody rb = bodies[i];
                    if (rb == null) continue;

                    float distance = Vector3.Distance(rb.worldCenterOfMass, point);
                    if (distance < bestDistance)
                    {
                        bestDistance = distance;
                        best = rb.transform;
                    }
                }

                if (best == null) best = unit.transform;
            }
            catch (Exception)
            {
            }

            return best;
        }

        private static void SpawnBoneStub(Rigidbody side, Vector3 anchor, Vector3 axis)
        {
            if (side == null) return;
            SpawnBone(side.transform, anchor, axis, 1f);
        }

        private static void SpawnBone(Transform parent, Vector3 worldPosition, Vector3 axis, float scale)
        {
            if (parent == null) return;

            try
            {
                while (_bones.Count >= MaxBones)
                {
                    GameObject oldest = _bones[0];
                    _bones.RemoveAt(0);
                    if (oldest != null) UnityEngine.Object.Destroy(oldest);
                }

                GameObject bone = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                Collider collider = bone.GetComponent<Collider>();
                if (collider != null) UnityEngine.Object.Destroy(collider);

                float radius = 0.035f * scale;
                float length = 0.13f * scale;
                bone.transform.localScale = new Vector3(radius * 2f, length, radius * 2f);
                bone.transform.position = worldPosition + axis * (length * 0.55f);
                bone.transform.rotation = Quaternion.FromToRotation(Vector3.up, axis);

                Renderer renderer = bone.GetComponent<Renderer>();
                if (renderer != null) renderer.sharedMaterial = GoreMaterials.Bone;

                bone.transform.SetParent(parent, true);

                // A little dried blood where the bone broke through.
                GameObject ring = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                Collider ringCollider = ring.GetComponent<Collider>();
                if (ringCollider != null) UnityEngine.Object.Destroy(ringCollider);
                ring.transform.localScale = new Vector3(radius * 3f, radius * 2f, radius * 3f);
                ring.transform.position = worldPosition - axis * (radius * 1.2f);
                Renderer ringRenderer = ring.GetComponent<Renderer>();
                if (ringRenderer != null) ringRenderer.sharedMaterial = GoreMaterials.FreshBlood;
                ring.transform.SetParent(parent, true);
                UnityEngine.Object.Destroy(ring, 25f);

                _bones.Add(bone);
                UnityEngine.Object.Destroy(bone, 25f);
            }
            catch (Exception)
            {
            }
        }

        private static void BoneChips(Vector3 position, Vector3 direction)
        {
            try
            {
                int chips = UnityEngine.Random.Range(1, 4);
                for (int i = 0; i < chips; i++)
                {
                    GameObject chip = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    float s = UnityEngine.Random.Range(0.04f, 0.09f);
                    chip.transform.localScale = new Vector3(s, s * 0.5f, s * 0.7f);
                    chip.transform.position = position + UnityEngine.Random.insideUnitSphere * 0.08f;

                    Renderer renderer = chip.GetComponent<Renderer>();
                    if (renderer != null) renderer.sharedMaterial = GoreMaterials.Bone;

                    Rigidbody body = chip.AddComponent<Rigidbody>();
                    body.mass = 0.05f;
                    body.drag = 0.45f;
                    body.angularDrag = 1.5f;
                    body.maxAngularVelocity = 8f;

                    Vector3 dir = UnityEngine.Random.insideUnitSphere;
                    dir.y = Mathf.Abs(dir.y) + 0.4f;
                    dir.Normalize();
                    if (direction.sqrMagnitude > 0.001f)
                        dir = (dir * 0.5f + direction.normalized * 0.8f).normalized;

                    body.AddForce(dir * UnityEngine.Random.Range(1.1f, 2.4f), ForceMode.VelocityChange);
                    body.AddTorque(UnityEngine.Random.insideUnitSphere * 2.5f, ForceMode.VelocityChange);

                    Transform root = BloodSystem.EffectsRoot;
                    if (root != null) chip.transform.SetParent(root, true);

                    UnityEngine.Object.Destroy(chip, 12f);
                }
            }
            catch (Exception)
            {
            }
        }

        /// <summary>Keeps the severed limb dripping blood on the floor for a few seconds.</summary>
        internal static void Tick(float dt)
        {
            for (int i = _bleeding.Count - 1; i >= 0; i--)
            {
                BleedingLimb limb = _bleeding[i];

                if (limb.Body == null)
                {
                    _bleeding.RemoveAt(i);
                    continue;
                }

                limb.TimeLeft -= dt;
                if (limb.TimeLeft <= 0f)
                {
                    _bleeding.RemoveAt(i);
                    continue;
                }

                limb.DripTimer -= dt;
                if (limb.DripTimer > 0f) continue;

                limb.DripTimer = UnityEngine.Random.Range(0.1f, 0.22f);

                try
                {
                    Vector3 point = limb.Body.worldCenterOfMass;

                    // Never spray blood from a piece that already flew away from the cut.
                    if (Vector3.Distance(point, limb.Anchor) > limb.Reach) continue;

                    BloodSystem.Trickle(point);
                }
                catch (Exception)
                {
                    _bleeding.RemoveAt(i);
                }
            }

            TickLooseLimbs(dt);
        }

        /// <summary>
        /// Lets a torn-off piece fall, then makes it inert: the game's PhysicsAnimation keeps
        /// pushing its old limb rigidbodies (walk torques, stand forces), which made loose legs
        /// twitch and slide around forever.
        /// </summary>
        private static void TickLooseLimbs(float dt)
        {
            for (int i = _loose.Count - 1; i >= 0; i--)
            {
                LooseLimb loose = _loose[i];

                if (loose.Body == null)
                {
                    _loose.RemoveAt(i);
                    continue;
                }

                loose.Age += dt;
                loose.SettleTimer -= dt;

                if (loose.Settled)
                {
                    if (loose.Age > 12f) _loose.RemoveAt(i);
                    continue;
                }

                if (loose.SettleTimer > 0f) continue;

                try
                {
                    if (loose.Body.velocity.magnitude > 0.9f || loose.Body.angularVelocity.magnitude > 5f)
                    {
                        loose.SettleTimer = 1f;
                        continue;
                    }

                    // Dead-body layer, like the parts the game itself drops on death.
                    Collider[] colliders = loose.Body.GetComponentsInChildren<Collider>();
                    for (int c = 0; c < colliders.Length; c++)
                        if (colliders[c] != null) colliders[c].gameObject.layer = 8;

                    loose.Body.isKinematic = true;
                    loose.Settled = true;
                }
                catch (Exception)
                {
                    _loose.RemoveAt(i);
                }
            }
        }

        internal static void Clear()
        {
            _bleeding.Clear();
            _loose.Clear();
            _severCount.Clear();

            for (int i = 0; i < _bones.Count; i++)
            {
                if (_bones[i] != null) UnityEngine.Object.Destroy(_bones[i]);
            }
            _bones.Clear();
        }
    }
}
