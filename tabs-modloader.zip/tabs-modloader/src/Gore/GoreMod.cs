using System;
using System.Collections.Generic;
using TabsModLoader;
using UnityEngine;

namespace Gore
{
    /// <summary>
    /// Gore mod for TABS Pre-Alpha.
    ///
    ///  * blood comes out exactly where the hit landed (GameHooks.UnitDamage gives the real
    ///    contact point, direction and weapon of every UnitHandler.TakeDamage call);
    ///  * heavy blows tear limbs off by destroying the ragdoll joint closest to the impact,
    ///    leaving exposed bone on both stumps and an arterial bleed that stains the floor;
    ///  * blunt trauma also cracks bones without dismembering (bone shard poking out);
    ///  * blood sprays on the floor, stains it and pools under corpses.
    ///
    /// Keys: F3 liga/desliga o gore, F4 limpa o sangue da cena.
    /// </summary>
    [TabsMod("Gore", Version = "2.0.0", Author = "TabsModLoader")]
    public class GoreMod : TabsMod
    {
        private const float RescanInterval = 0.25f;
        private const float DismemberDamage = 70f;
        private const float BoneDamage = 55f;
        private const float CorpseBleedSeconds = 3.5f;

        private ModContext _ctx;
        private List<UnitHandler> _units = new List<UnitHandler>();

        private readonly Dictionary<int, float> _lastHealth = new Dictionary<int, float>();
        private readonly HashSet<int> _dead = new HashSet<int>();
        private readonly Dictionary<int, float> _corpseTimer = new Dictionary<int, float>();
        private readonly Dictionary<int, Vector3> _lastHit = new Dictionary<int, Vector3>();

        private float _rescanTimer;
        private float _trickleTimer;
        private int _hits;
        private int _deaths;

        public override void Load(ModContext ctx)
        {
            _ctx = ctx;
            ctx.Log("Gore v2 ativo: sangue no ponto do golpe, desmembramento e ossos expostos.");
            ctx.Log("F3 liga/desliga, F4 limpa o sangue. Golpes acima de " + Mathf.RoundToInt(DismemberDamage) + " de dano podem arrancar membros.");

            ctx.OnUnitDamaged(OnUnitDamaged);
            ctx.OnUpdate(Update);

            // Leftover effects from a previous battle are pointless.
            BloodSystem.Clear();
            Dismemberment.Clear();
        }

        public override void Unload()
        {
            try
            {
                BloodSystem.Clear();
                Dismemberment.Clear();
            }
            catch (Exception)
            {
            }
        }

        // ------------------------------------------------------------------ hits

        private void OnUnitDamaged(UnitDamaged e)
        {
            try
            {
                if (!BloodSystem.Enabled) return;
                if (e.Unit == null) return;

                _hits++;
                if (_hits == 1)
                    _ctx.Log("Hook de dano ativo: primeiro golpe recebido de '" + (string.IsNullOrEmpty(e.Weapon) ? "?" : e.Weapon) + "'.");

                Vector3 position = e.Position;
                if (position == Vector3.zero && e.Unit != null)
                    position = e.Unit.transform.position + Vector3.up * 0.8f;

                // Explosions report their own centre as the hit point; keep the blood on the body.
                position = ClampToBody(e.Unit, position);

                Vector3 direction = e.Direction;
                if (direction.sqrMagnitude > 1f) direction.Normalize();

                _lastHit[e.Unit.GetInstanceID()] = position;

                // Spray exactly at the contact point, thrown along the blow.
                BloodSystem.Hit(position, direction, e.Damage);
                if (e.Damage >= 80f)
                    BloodSystem.Hit(position, direction, e.Damage * 0.6f);

                string weapon = e.Weapon == null ? string.Empty : e.Weapon.ToLowerInvariant();
                bool blunt = weapon == "club" || weapon == "physical" || weapon == "explosive" || weapon == "self";

                // Bones breaking through the skin (no limb lost).
                if (blunt && e.Damage >= BoneDamage && UnityEngine.Random.value < 0.45f)
                {
                    Dismemberment.ExposeBone(position, direction,
                        Dismemberment.NearestPart(e.Unit, position), _ctx);
                }

                // Limbs coming off.
                if (e.Damage >= DismemberDamage)
                {
                    float chance = Mathf.Clamp01((e.Damage - DismemberDamage) / 110f) * 0.9f;
                    if (UnityEngine.Random.value < chance)
                    {
                        Dismemberment.TrySever(e.Unit, position, direction, e.Damage, weapon, _ctx);
                    }
                }
            }
            catch (Exception ex)
            {
                _ctx.LogException(ex);
            }
        }

        /// <summary>Keeps the spray on the victim instead of at a far-away explosion point.</summary>
        private static Vector3 ClampToBody(UnitHandler unit, Vector3 position)
        {
            if (unit == null) return position;

            try
            {
                Vector3 center = unit.transform.position + Vector3.up * 0.8f;
                if (Vector3.Distance(position, center) <= 1.2f) return position;

                Transform part = Dismemberment.NearestPart(unit, position);
                if (part != null && Vector3.Distance(part.position, position) > 0.6f)
                    return part.position;
            }
            catch (Exception)
            {
            }

            return position;
        }

        // ------------------------------------------------------------------ frame

        private void Update()
        {
            float dt = Time.deltaTime;

            HandleKeys();
            BloodSystem.Tick(dt);
            Dismemberment.Tick(dt);

            _rescanTimer -= dt;
            if (_rescanTimer <= 0f)
            {
                _rescanTimer = RescanInterval;
                Rescan();
                ScanUnits();
            }

            _trickleTimer -= dt;
            if (_trickleTimer <= 0f)
            {
                _trickleTimer = 0.35f;
                TrickleWounded();
                BleedCorpses();
            }
        }

        private void HandleKeys()
        {
            try
            {
                if (Input.GetKeyDown(KeyCode.F3))
                {
                    BloodSystem.Enabled = !BloodSystem.Enabled;
                    _ctx.Log("Gore " + (BloodSystem.Enabled ? "LIGADO" : "DESLIGADO") + ".");
                }

                if (Input.GetKeyDown(KeyCode.F4))
                {
                    BloodSystem.Clear();
                    Dismemberment.Clear();
                    _ctx.Log("Sangue e ossos da cena limpos.");
                }
            }
            catch (Exception e)
            {
                _ctx.LogException(e);
            }
        }

        private void Rescan()
        {
            var list = new List<UnitHandler>();

            try
            {
                GameLogic game = GameLogic.Instance;
                if (game != null && game.SpawnedUnits != null)
                {
                    List<UnitHandler> spawned = game.SpawnedUnits;
                    for (int i = 0; i < spawned.Count; i++)
                    {
                        UnitHandler u = spawned[i];
                        if (u != null) list.Add(u);
                    }
                }
            }
            catch (Exception)
            {
            }

            if (list.Count == 0)
            {
                try
                {
                    UnitHandler[] found = UnityEngine.Object.FindObjectsOfType<UnitHandler>();
                    for (int i = 0; i < found.Length; i++)
                    {
                        if (found[i] != null) list.Add(found[i]);
                    }
                }
                catch (Exception)
                {
                }
            }

            _units = list;
        }

        private void ScanUnits()
        {
            if (_units.Count == 0) return;

            for (int i = 0; i < _units.Count; i++)
            {
                UnitHandler unit = _units[i];
                if (unit == null) continue;

                int id;
                try
                {
                    id = unit.GetInstanceID();
                }
                catch (Exception)
                {
                    continue;
                }

                if (!unit.Alive)
                {
                    if (_dead.Add(id))
                        OnUnitDied(id, unit);
                    continue;
                }

                float health;
                try
                {
                    health = unit.Health;
                }
                catch (Exception)
                {
                    continue;
                }

                _lastHealth[id] = health;
            }
        }

        private void OnUnitDied(int id, UnitHandler unit)
        {
            _deaths++;

            Vector3 position = unit != null ? unit.transform.position + Vector3.up * 0.7f : Vector3.zero;
            Vector3 direction = Vector3.zero;

            Vector3 last;
            if (_lastHit.TryGetValue(id, out last))
                direction = (last - (unit != null ? unit.transform.position : last)).normalized;

            try
            {
                BloodSystem.Death(position, direction);
                _corpseTimer[id] = CorpseBleedSeconds;

                _ctx.Log("Morte com gore: " + _deaths + " (respingos: " + BloodSystem.LiveDroplets +
                         ", manchas: " + BloodSystem.LiveDecals + ", carne: " + BloodSystem.LiveMeat + ").");
            }
            catch (Exception e)
            {
                _ctx.LogException(e);
            }
        }

        private void BleedCorpses()
        {
            if (_corpseTimer.Count == 0) return;

            // Copy the keys first: Unity's Mono invalidates the enumerator on value writes too.
            var keys = new List<int>(_corpseTimer.Keys);

            for (int i = 0; i < keys.Count; i++)
            {
                float left = _corpseTimer[keys[i]] - 0.35f;

                if (left <= 0f)
                {
                    _corpseTimer.Remove(keys[i]);
                    _lastHit.Remove(keys[i]);
                    continue;
                }

                _corpseTimer[keys[i]] = left;
            }

            for (int i = 0; i < _units.Count; i++)
            {
                UnitHandler unit = _units[i];
                if (unit == null || unit.Alive) continue;

                float left;
                if (!_corpseTimer.TryGetValue(unit.GetInstanceID(), out left)) continue;

                Vector3 ground = unit.transform.position;
                BloodSystem.Pool(ground);
            }
        }

        private void TrickleWounded()
        {
            if (_units.Count == 0) return;

            for (int i = 0; i < _units.Count; i++)
            {
                UnitHandler unit = _units[i];
                if (unit == null || !unit.Alive) continue;

                float health;
                if (!_lastHealth.TryGetValue(unit.GetInstanceID(), out health)) continue;
                if (health > 35f) continue;

                if (UnityEngine.Random.value < 0.5f)
                    BloodSystem.Trickle(unit.transform.position + Vector3.up * 0.8f);
            }
        }
    }
}
