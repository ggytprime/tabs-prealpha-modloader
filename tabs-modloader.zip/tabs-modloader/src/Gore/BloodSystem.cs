using System;
using System.Collections.Generic;
using UnityEngine;

namespace Gore
{
    /// <summary>
    /// Procedural blood: droplets (moved by hand, no physics), meat chunks (rigidbodies) and
    /// textured splats/pools that stay on the floor. Everything is built from primitives and
    /// runtime materials, so the mod ships no assets.
    /// </summary>
    internal static class BloodSystem
    {
        private sealed class Droplet
        {
            public GameObject Go;
            public Vector3 Velocity;
            public float Life;
            public float Age;
            public float Size;
            public Vector3 GroundNormal;
            public float GroundY;
        }

        private sealed class Decal
        {
            public GameObject Go;
            public float Life;
            public Color Tint;
        }

        private static readonly List<Droplet> _droplets = new List<Droplet>();
        private static readonly List<Decal> _decals = new List<Decal>();
        private static readonly List<GameObject> _meat = new List<GameObject>();
        private static readonly RaycastHit[] _hitBuffer = new RaycastHit[32];

        private static Transform _root;
        private static Mesh _quadMesh;

        internal const int MaxDroplets = 340;
        internal const int MaxDecals = 190;
        internal const int MaxMeat = 70;

        internal static bool Enabled = true;

        internal static int LiveDroplets { get { return _droplets.Count; } }
        internal static int LiveDecals { get { return _decals.Count; } }
        internal static int LiveMeat { get { return _meat.Count; } }

        private static Transform Root
        {
            get
            {
                if (_root != null) return _root;
                try
                {
                    var go = new GameObject("GoreEffects");
                    UnityEngine.Object.DontDestroyOnLoad(go);
                    go.hideFlags = HideFlags.HideInHierarchy;
                    _root = go.transform;
                }
                catch (Exception)
                {
                }
                return _root;
            }
        }

        // ------------------------------------------------------------- ground

        private struct GroundHit
        {
            public Vector3 Point;
            public Vector3 Normal;
        }

        /// <summary>
        /// Lowest solid surface under a point. Every hit is considered, so the victim's own body
        /// colliders (which sit above the floor) cannot swallow the droplets.
        /// </summary>
        private static GroundHit GroundBelow(Vector3 position)
        {
            var hitInfo = new GroundHit { Normal = Vector3.up, Point = position - Vector3.up * 5f };

            try
            {
                int count = Physics.RaycastNonAlloc(position + Vector3.up * 0.5f, Vector3.down, _hitBuffer, 80f);
                bool found = false;
                float lowest = 0f;

                for (int i = 0; i < count; i++)
                {
                    RaycastHit hit = _hitBuffer[i];
                    if (hit.collider == null || hit.collider.isTrigger) continue;
                    if (!found || hit.point.y < lowest)
                    {
                        lowest = hit.point.y;
                        hitInfo.Point = hit.point;
                        hitInfo.Normal = hit.normal.sqrMagnitude > 0.1f ? hit.normal.normalized : Vector3.up;
                        found = true;
                    }
                }
            }
            catch (Exception)
            {
            }

            return hitInfo;
        }

        // ------------------------------------------------------------- public API

        /// <summary>Spray of blood exactly where a unit was hit, thrown along the hit direction.</summary>
        internal static void Hit(Vector3 position, Vector3 direction, float damage)
        {
            if (!Enabled) return;

            int count = Mathf.Clamp(Mathf.RoundToInt(damage * 0.4f), 2, 16);
            SpawnDroplets(position, direction, count, 1.1f, 3.5f);
        }

        /// <summary>Big burst when a unit dies, plus meat chunks and a pool under the body.</summary>
        internal static void Death(Vector3 position, Vector3 direction)
        {
            if (!Enabled) return;

            SpawnDroplets(position, direction, 26, 1.7f, 7f);
            Pool(position);

            int chunks = UnityEngine.Random.Range(3, 8);
            for (int i = 0; i < chunks; i++)
                SpawnMeat(position, direction, 1f);
        }

        /// <summary>Arterial burst when a limb is torn off.</summary>
        internal static void SeverBurst(Vector3 position, Vector3 direction)
        {
            if (!Enabled) return;

            SpawnDroplets(position, direction, 34, 2.2f, 8f);
            Pool(position);

            int chunks = UnityEngine.Random.Range(2, 5);
            for (int i = 0; i < chunks; i++)
                SpawnMeat(position, direction, 0.7f);
        }

        /// <summary>Bleeding while a hurt unit (or a severed limb) is still around.</summary>
        internal static void Trickle(Vector3 position)
        {
            if (!Enabled) return;
            SpawnDroplets(position, Vector3.zero, 2, 0.6f, 2f);
        }

        /// <summary>Blood puddle on the floor. Calling it repeatedly grows the puddle.</summary>
        internal static void Pool(Vector3 position)
        {
            if (!Enabled) return;

            GroundHit ground = GroundBelow(position);
            float radius = UnityEngine.Random.Range(1.1f, 2.1f);

            SpawnDecal(ground, radius, GoreMaterials.DarkBlood, 70f, 0.95f);
            SpawnDecal(ground, radius * UnityEngine.Random.Range(0.45f, 0.7f), GoreMaterials.SplatDecal,
                70f, 1f);
        }

        // ------------------------------------------------------------- droplets

        private static void SpawnDroplets(Vector3 position, Vector3 direction, int count, float speed, float life)
        {
            if (_droplets.Count >= MaxDroplets) return;

            GroundHit ground = GroundBelow(position);

            for (int i = 0; i < count; i++)
            {
                if (_droplets.Count >= MaxDroplets) break;

                try
                {
                    GameObject go = GoreMaterials.Primitive(PrimitiveType.Sphere, Root, "BloodDrop");

                    float size = UnityEngine.Random.Range(0.05f, 0.13f);
                    go.transform.localScale = new Vector3(size, size * 0.8f, size);
                    go.transform.position = position + UnityEngine.Random.insideUnitSphere * 0.22f;

                    GoreMaterials.SetMaterial(go, UnityEngine.Random.value > 0.75f
                        ? GoreMaterials.DarkBlood
                        : GoreMaterials.FreshBlood);

                    Vector3 dir = UnityEngine.Random.insideUnitSphere;
                    dir.y = Mathf.Abs(dir.y) + 0.6f;
                    dir.Normalize();

                    // Thrown along the blow, with a cone of spread.
                    if (direction.sqrMagnitude > 0.001f)
                        dir = (dir * 0.55f + direction.normalized * 0.95f).normalized;

                    _droplets.Add(new Droplet
                    {
                        Go = go,
                        Velocity = dir * UnityEngine.Random.Range(speed * 0.6f, speed * 1.6f) + Vector3.up * 1.5f,
                        Life = UnityEngine.Random.Range(life * 0.6f, life),
                        GroundY = ground.Point.y,
                        GroundNormal = ground.Normal,
                        Size = size
                    });
                }
                catch (Exception)
                {
                    return;
                }
            }
        }

        internal static Transform EffectsRoot
        {
            get { return Root; }
        }

        /// <summary>Single meat chunk (used by the dismemberment code at the stump).</summary>
        internal static void MeatChunk(Vector3 position, Vector3 direction, float scale)
        {
            SpawnMeat(position, direction, scale);
        }

        // ------------------------------------------------------------- meat

        private static void SpawnMeat(Vector3 position, Vector3 direction, float scale)
        {
            if (_meat.Count >= MaxMeat) return;

            try
            {
                GameObject chunk = GoreMaterials.Primitive(PrimitiveType.Sphere, Root, "MeatChunk");

                // Irregular, uneven blob instead of a clean ball.
                float s = UnityEngine.Random.Range(0.09f, 0.19f) * scale;
                chunk.transform.localScale = new Vector3(
                    s * UnityEngine.Random.Range(0.7f, 1.4f),
                    s * UnityEngine.Random.Range(0.5f, 1.0f),
                    s * UnityEngine.Random.Range(0.7f, 1.3f));
                chunk.transform.rotation = UnityEngine.Random.rotation;
                chunk.transform.position = position + UnityEngine.Random.insideUnitSphere * 0.25f;

                GoreMaterials.SetMaterial(chunk, UnityEngine.Random.value > 0.65f
                    ? GoreMaterials.DarkBlood
                    : GoreMaterials.Meat);

                Rigidbody body = chunk.AddComponent<Rigidbody>();
                body.mass = 0.12f;
                body.drag = 0.4f;
                body.angularDrag = 1.4f;
                body.maxAngularVelocity = 8f;

                Vector3 dir = UnityEngine.Random.insideUnitSphere;
                dir.y = Mathf.Abs(dir.y) + 0.5f;
                dir.Normalize();
                if (direction.sqrMagnitude > 0.001f)
                    dir = (dir * 0.6f + direction.normalized * 0.8f).normalized;

                // VelocityChange keeps small chunks from being flung across the map.
                body.AddForce(dir * UnityEngine.Random.Range(0.9f, 2.2f), ForceMode.VelocityChange);
                body.AddTorque(UnityEngine.Random.insideUnitSphere * 2f, ForceMode.VelocityChange);

                _meat.Add(chunk);
                UnityEngine.Object.Destroy(chunk, UnityEngine.Random.Range(20f, 35f));
            }
            catch (Exception)
            {
            }
        }

        // ------------------------------------------------------------- decals

        private static Mesh QuadMesh
        {
            get
            {
                if (_quadMesh != null) return _quadMesh;

                var mesh = new Mesh();
                mesh.name = "GoreQuad";
                mesh.vertices = new[]
                {
                    new Vector3(-0.5f, 0f, -0.5f),
                    new Vector3(0.5f, 0f, -0.5f),
                    new Vector3(0.5f, 0f, 0.5f),
                    new Vector3(-0.5f, 0f, 0.5f)
                };
                mesh.normals = new[] { Vector3.up, Vector3.up, Vector3.up, Vector3.up };
                mesh.uv = new[] { new Vector2(0f, 0f), new Vector2(1f, 0f), new Vector2(1f, 1f), new Vector2(0f, 1f) };
                mesh.triangles = new[] { 0, 2, 1, 0, 3, 2 };
                mesh.RecalculateBounds();

                _quadMesh = mesh;
                return _quadMesh;
            }
        }

        /// <summary>Lays a textured blood splat on the surface, aligned with its normal.</summary>
        private static void SpawnDecal(GroundHit ground, float size, Material material, float life, float alpha)
        {
            if (material == null) return;

            while (_decals.Count >= MaxDecals)
            {
                Decal oldest = _decals[0];
                _decals.RemoveAt(0);
                if (oldest.Go != null) UnityEngine.Object.Destroy(oldest.Go);
            }

            try
            {
                var go = new GameObject("BloodSplat");
                go.transform.SetParent(Root, true);

                var filter = go.AddComponent<MeshFilter>();
                filter.sharedMesh = QuadMesh;

                var renderer = go.AddComponent<MeshRenderer>();
                renderer.sharedMaterial = material;
                renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
                renderer.receiveShadows = false;

                go.transform.rotation = Quaternion.FromToRotation(Vector3.up, ground.Normal) *
                                        Quaternion.Euler(0f, UnityEngine.Random.Range(0f, 360f), 0f);
                go.transform.position = ground.Point + ground.Normal * 0.012f;
                go.transform.localScale = new Vector3(size, 1f, size);

                var tint = new MaterialPropertyBlock();
                tint.SetColor("_Color", new Color(0.55f, 0.02f, 0.02f, alpha));
                renderer.SetPropertyBlock(tint);

                _decals.Add(new Decal { Go = go, Life = life, Tint = new Color(1f, 1f, 1f, alpha) });
            }
            catch (Exception)
            {
            }
        }

        // ------------------------------------------------------------- frame

        /// <summary>Moves the droplets and expires stains; called every frame by the mod.</summary>
        internal static void Tick(float dt)
        {
            PruneDecals();

            if (_droplets.Count > 0)
            {
                for (int i = _droplets.Count - 1; i >= 0; i--)
                {
                    Droplet d = _droplets[i];

                    if (d == null || d.Go == null)
                    {
                        _droplets.RemoveAt(i);
                        continue;
                    }

                    d.Life -= dt;
                    if (d.Life <= 0f)
                    {
                        Cleanup(d);
                        _droplets.RemoveAt(i);
                        continue;
                    }

                    try
                    {
                        d.Age += dt;
                        d.Velocity.y -= 22f * dt;
                        Vector3 pos = d.Go.transform.position + d.Velocity * dt;

                        if (d.Age > 0.12f && pos.y <= d.GroundY)
                        {
                            // Part of the spray leaves a stain instead of just vanishing.
                            if (UnityEngine.Random.value < 0.55f)
                            {
                                var hit = new GroundHit { Point = new Vector3(pos.x, d.GroundY, pos.z), Normal = d.GroundNormal };
                                SpawnDecal(hit, UnityEngine.Random.Range(0.18f, 0.42f),
                                    UnityEngine.Random.value > 0.5f ? GoreMaterials.SplatDecal : GoreMaterials.DarkBlood,
                                    UnityEngine.Random.Range(16f, 30f), 0.9f);
                            }

                            Cleanup(d);
                            _droplets.RemoveAt(i);
                            continue;
                        }

                        d.Go.transform.position = pos;

                        // Shrinks a little as it flies, so it reads as spatter.
                        float t = Mathf.Clamp01(d.Life * 1.5f);
                        d.Go.transform.localScale = new Vector3(d.Size * t, d.Size * 0.8f * t, d.Size * t);
                    }
                    catch (Exception)
                    {
                        _droplets.RemoveAt(i);
                    }
                }
            }
        }

        private static void Cleanup(Droplet d)
        {
            if (d == null || d.Go == null) return;
            UnityEngine.Object.Destroy(d.Go);
        }

        private static void PruneDecals()
        {
            for (int i = _decals.Count - 1; i >= 0; i--)
            {
                Decal decal = _decals[i];
                if (decal.Go == null)
                {
                    _decals.RemoveAt(i);
                    continue;
                }

                decal.Life -= Time.deltaTime;
                if (decal.Life <= 0f)
                {
                    UnityEngine.Object.Destroy(decal.Go);
                    _decals.RemoveAt(i);
                }
            }

            for (int i = _meat.Count - 1; i >= 0; i--)
            {
                if (_meat[i] == null) _meat.RemoveAt(i);
            }
        }

        internal static void Clear()
        {
            for (int i = 0; i < _droplets.Count; i++) Cleanup(_droplets[i]);
            _droplets.Clear();

            for (int i = 0; i < _decals.Count; i++)
            {
                if (_decals[i].Go != null) UnityEngine.Object.Destroy(_decals[i].Go);
            }
            _decals.Clear();

            for (int i = 0; i < _meat.Count; i++)
            {
                if (_meat[i] != null) UnityEngine.Object.Destroy(_meat[i]);
            }
            _meat.Clear();
        }
    }
}
