using System;
using System.Collections.Generic;
using System.IO;
using Mono.Cecil;
using Mono.Cecil.Cil;

/// <summary>
/// Patches Assembly-CSharp.dll so the loader can see the game:
///
///  * GameLogic.Awake() calls TabsModLoader.Bootstrap.Init() first (starts the loader).
///  * UnitHandler.TakeDamage() calls TabsModLoader.GameHooks.UnitDamage(unit, damage,
///    dir, weapon, worldPosition) right before it subtracts health, so mods get the exact
///    contact point, direction, weapon name and victim of every hit.
///
/// usage: Patcher.exe &lt;Managed\Assembly-CSharp.dll&gt; [TabsModLoader.dll]
/// Both patches are idempotent: re-running never duplicates a call.
/// </summary>
internal static class Program
{
    private const string LoaderAssembly = "TabsModLoader";
    private const string HooksType = "GameHooks";
    private const string HooksMethod = "UnitDamage";

    private static int Main(string[] args)
    {
        if (args.Length < 1)
        {
            Console.Error.WriteLine("usage: Patcher.exe <...\\Managed\\Assembly-CSharp.dll> [TabsModLoader.dll]");
            return 2;
        }

        string asmPath = Path.GetFullPath(args[0]);
        if (!File.Exists(asmPath))
        {
            Console.Error.WriteLine("Assembly not found: " + asmPath);
            return 3;
        }

        string loaderPath = args.Length > 1
            ? Path.GetFullPath(args[1])
            : Path.Combine(Path.GetDirectoryName(asmPath) ?? ".", "TabsModLoader.dll");

        Console.WriteLine("Assembly : " + asmPath);
        Console.WriteLine("Loader   : " + loaderPath);

        if (!File.Exists(loaderPath))
        {
            Console.Error.WriteLine("ERROR: TabsModLoader.dll not found at " + loaderPath);
            return 7;
        }

        try
        {
            bool changed = false;

            using (AssemblyDefinition loaderAsm = AssemblyDefinition.ReadAssembly(loaderPath,
                       new ReaderParameters { InMemory = true, ReadSymbols = false }))
            using (AssemblyDefinition gameAsm = AssemblyDefinition.ReadAssembly(asmPath,
                       new ReaderParameters { InMemory = true, ReadSymbols = false }))
            {
                // ---- bootstrap: GameLogic.Awake() -> Bootstrap.Init() -------------
                MethodDefinition initMethod = FindStaticMethod(loaderAsm, "Bootstrap", "Init");
                if (initMethod == null)
                {
                    Console.Error.WriteLine("ERROR: TabsModLoader.Bootstrap.Init() not found in loader DLL.");
                    return 8;
                }

                TypeDefinition gameLogic = FindType(gameAsm, "GameLogic");
                if (gameLogic == null)
                {
                    Console.Error.WriteLine("ERROR: type 'GameLogic' not found in Assembly-CSharp.dll.");
                    return 5;
                }

                MethodDefinition awake = FindMethod(gameLogic, "Awake", 0);
                if (awake == null || !awake.HasBody)
                {
                    Console.Error.WriteLine("ERROR: GameLogic.Awake() not found or has no body.");
                    return 6;
                }

                if (AlreadyCalls(awake, "Bootstrap", "Init"))
                {
                    Console.WriteLine("[1/2] GameLogic.Awake() already patched.");
                }
                else
                {
                    MethodReference initRef = gameAsm.MainModule.ImportReference(initMethod);
                    ILProcessor il = awake.Body.GetILProcessor();
                    il.InsertBefore(awake.Body.Instructions[0], il.Create(OpCodes.Call, initRef));
                    changed = true;
                    Console.WriteLine("[1/2] GameLogic.Awake() now calls TabsModLoader.Bootstrap.Init().");
                }

                // ---- damage hook: UnitHandler.TakeDamage() ------------------------
                TypeDefinition unitHandler = FindType(gameAsm, "UnitHandler");
                if (unitHandler == null)
                {
                    Console.Error.WriteLine("ERROR: type 'UnitHandler' not found in Assembly-CSharp.dll.");
                    return 12;
                }

                MethodDefinition takeDamage = null;
                foreach (MethodDefinition m in unitHandler.Methods)
                {
                    if (m.Name == "TakeDamage" && m.HasBody && m.Parameters.Count == 4)
                    {
                        takeDamage = m;
                        break;
                    }
                }

                if (takeDamage == null)
                {
                    Console.Error.WriteLine("ERROR: UnitHandler.TakeDamage(float, Vector3, string, Vector3) not found.");
                    return 13;
                }

                if (AlreadyCalls(takeDamage, HooksType, HooksMethod))
                {
                    Console.WriteLine("[2/2] UnitHandler.TakeDamage() already patched.");
                }
                else
                {
                    if (!InjectDamageHook(gameAsm, takeDamage))
                    {
                        Console.Error.WriteLine(
                            "ERROR: could not find the 'm_health -= damage' pattern inside UnitHandler.TakeDamage(); " +
                            "the game assembly looks different from the supported build. IL dump:");
                        DumpIl(takeDamage);
                        return 14;
                    }
                    changed = true;
                    Console.WriteLine("[2/2] UnitHandler.TakeDamage() now reports hits to GameHooks.UnitDamage().");
                }

                if (!changed)
                {
                    Console.WriteLine("Already patched - nothing to do.");
                    return 0;
                }

                // ---- write ------------------------------------------------------
                string backup = asmPath + ".bak";
                if (!File.Exists(backup))
                {
                    File.Copy(asmPath, backup, true);
                    Console.WriteLine("Backup   : " + backup);
                }
                else
                {
                    Console.WriteLine("Backup   : " + backup + " (kept)");
                }

                string temp = asmPath + ".patched.tmp";
                gameAsm.Write(temp);

                if (!File.Exists(temp) || new FileInfo(temp).Length == 0)
                {
                    Console.Error.WriteLine("ERROR: Cecil produced no output; original left untouched.");
                    return 10;
                }

                gameAsm.Dispose();
                File.Copy(temp, asmPath, true);
                File.Delete(temp);
            }

            Console.WriteLine("OK: Assembly-CSharp.dll patched.");
            return 0;
        }
        catch (Exception e)
        {
            Console.Error.WriteLine("ERROR: " + e);
            return 11;
        }
    }

    /// <summary>
    /// Inserts <c>GameHooks.UnitDamage(this, damage, dir, damager, worldPosition)</c> right
    /// before the health subtraction, i.e. after the game's own immunity check passed.
    /// </summary>
    private static bool InjectDamageHook(AssemblyDefinition gameAsm, MethodDefinition takeDamage)
    {
        IList<Instruction> code = takeDamage.Body.Instructions;

        // Expected shape, as emitted by the Mono compiler used for this build:
        //   ldarg.0 / dup / ldfld m_health / ldarg.1 / sub / stfld m_health
        // (older/newer compilers may drop the dup, so both forms are accepted)
        int insertAt = -1;
        for (int i = 5; i < code.Count; i++)
        {
            Instruction store = code[i];
            if (store.OpCode != OpCodes.Stfld) continue;

            FieldReference field = store.Operand as FieldReference;
            if (field == null || field.Name != "m_health") continue;

            if (code[i - 1].OpCode != OpCodes.Sub) continue;
            if (code[i - 2].OpCode != OpCodes.Ldarg_1) continue;

            Instruction load = code[i - 3];
            FieldReference health = load.Operand as FieldReference;
            if (load.OpCode != OpCodes.Ldfld || health == null || health.Name != "m_health") continue;

            if (code[i - 4].OpCode == OpCodes.Dup && code[i - 5].OpCode == OpCodes.Ldarg_0)
                insertAt = i - 5;
            else if (code[i - 4].OpCode == OpCodes.Ldarg_0)
                insertAt = i - 4;
            else
                continue;

            break;
        }

        if (insertAt < 0) return false;

        // UnityEngine.Vector3 must be referenced exactly as the game module already does.
        TypeReference vector3 = null;
        foreach (TypeReference reference in gameAsm.MainModule.GetTypeReferences())
        {
            if (reference.FullName == "UnityEngine.Vector3") { vector3 = reference; break; }
        }

        if (vector3 == null)
        {
            Console.Error.WriteLine("ERROR: UnityEngine.Vector3 is not referenced by Assembly-CSharp.dll.");
            return false;
        }

        AssemblyNameReference loaderScope = null;
        foreach (AssemblyNameReference reference in gameAsm.MainModule.AssemblyReferences)
        {
            if (reference.Name == LoaderAssembly) { loaderScope = reference; break; }
        }

        if (loaderScope == null)
        {
            Console.Error.WriteLine("ERROR: the patched module does not reference " + LoaderAssembly + " (run the Awake patch first).");
            return false;
        }

        var hooksType = new TypeReference("TabsModLoader", HooksType, gameAsm.MainModule, loaderScope, false);
        var hooksMethod = new MethodReference(HooksMethod, gameAsm.MainModule.TypeSystem.Void, hooksType);
        hooksMethod.HasThis = false;
        hooksMethod.Parameters.Add(new ParameterDefinition(FindType(gameAsm, "UnitHandler")));
        hooksMethod.Parameters.Add(new ParameterDefinition(gameAsm.MainModule.TypeSystem.Single));
        hooksMethod.Parameters.Add(new ParameterDefinition(vector3));
        hooksMethod.Parameters.Add(new ParameterDefinition(gameAsm.MainModule.TypeSystem.String));
        hooksMethod.Parameters.Add(new ParameterDefinition(vector3));

        ILProcessor il = takeDamage.Body.GetILProcessor();
        Instruction anchor = code[insertAt];

        il.InsertBefore(anchor, il.Create(OpCodes.Ldarg_0));
        il.InsertBefore(anchor, il.Create(OpCodes.Ldarg_1));
        il.InsertBefore(anchor, il.Create(OpCodes.Ldarg_2));
        il.InsertBefore(anchor, il.Create(OpCodes.Ldarg_3));
        il.InsertBefore(anchor, il.Create(OpCodes.Ldarg, takeDamage.Parameters[3]));
        il.InsertBefore(anchor, il.Create(OpCodes.Call, hooksMethod));

        // Any branch that jumped straight to the subtraction still lands on the call.
        takeDamage.Body.MaxStackSize = Math.Max(takeDamage.Body.MaxStackSize, (short)8);
        return true;
    }

    private static void DumpIl(MethodDefinition method)
    {
        if (!method.HasBody) return;
        foreach (Instruction instruction in method.Body.Instructions)
        {
            Console.Error.WriteLine("  " + instruction);
        }
    }

    private static MethodDefinition FindStaticMethod(AssemblyDefinition asm, string typeName, string methodName)
    {
        foreach (TypeDefinition type in asm.MainModule.Types)
        {
            if (type.Name != typeName) continue;
            foreach (MethodDefinition method in type.Methods)
            {
                if (method.Name == methodName && method.IsStatic && method.Parameters.Count == 0)
                    return method;
            }
        }
        return null;
    }

    private static TypeDefinition FindType(AssemblyDefinition asm, string name)
    {
        foreach (TypeDefinition type in asm.MainModule.Types)
        {
            if (type.Name == name) return type;
        }
        return null;
    }

    private static MethodDefinition FindMethod(TypeDefinition type, string name, int parameterCount)
    {
        foreach (MethodDefinition method in type.Methods)
        {
            if (method.Name == name && method.Parameters.Count == parameterCount) return method;
        }
        return null;
    }

    private static bool AlreadyCalls(MethodDefinition method, string typeName, string methodName)
    {
        if (!method.HasBody) return false;
        foreach (Instruction instruction in method.Body.Instructions)
        {
            if (instruction.OpCode != OpCodes.Call) continue;

            MethodReference target = instruction.Operand as MethodReference;
            if (target == null) continue;
            if (target.Name != methodName) continue;
            if (target.DeclaringType != null && target.DeclaringType.Name == typeName) return true;
        }
        return false;
    }
}
