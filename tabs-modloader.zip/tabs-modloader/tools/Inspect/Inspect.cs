using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Mono.Cecil;

internal static class Inspect
{
    private static int Main(string[] args)
    {
        if (args.Length < 1)
        {
            Console.Error.WriteLine("usage: Inspect <assembly.dll> [filter]");
            return 2;
        }
        var path = args[0];
        var filter = args.Length > 1 ? args[1] : null;
        var asm = AssemblyDefinition.ReadAssembly(path);
        Console.WriteLine("ASSEMBLY " + asm.Name.FullName);

        foreach (var t in asm.MainModule.Types.SelectMany(All))
        {
            if (t.Name.StartsWith("<")) continue;
            var full = t.FullName;
            if (filter != null && full.IndexOf(filter, StringComparison.OrdinalIgnoreCase) < 0) continue;

            Console.WriteLine();
            Console.WriteLine((t.IsInterface ? "interface " : t.IsEnum ? "enum " : t.IsValueType ? "struct " : "class ") + full + (t.BaseType != null ? " : " + t.BaseType.FullName : ""));
            foreach (var f in t.Fields)
                Console.WriteLine("    field " + (f.IsStatic ? "static " : "") + f.FieldType.FullName + " " + f.Name);
            foreach (var p in t.Properties)
                Console.WriteLine("    prop " + p.PropertyType.FullName + " " + p.Name);
            foreach (var m in t.Methods)
            {
                if (m.IsGetter || m.IsSetter) continue;
                Console.WriteLine("    method " + (m.IsStatic ? "static " : "") + (m.IsPublic ? "public " : m.IsPrivate ? "private " : "internal ") +
                                  m.ReturnType.FullName + " " + m.Name + "(" + string.Join(", ", m.Parameters.Select(x => x.ParameterType.FullName + " " + x.Name).ToArray()) + ")");
            }
        }
        return 0;
    }

    private static IEnumerable<TypeDefinition> All(TypeDefinition t)
    {
        yield return t;
        foreach (var n in t.NestedTypes.SelectMany(All)) yield return n;
    }
}
