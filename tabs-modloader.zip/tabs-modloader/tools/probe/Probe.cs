using System;
using System.IO;
using System.Reflection;
using UnityEngine;

namespace Doorstop
{
    public class Entrypoint
    {
        private static string _log = "probe.log";

        public static void Main()
        {
            Start();
        }

        public static void Start()
        {
            try
            {
                var exe = Environment.GetEnvironmentVariable("DOORSTOP_PROCESS_PATH");
                _log = Path.Combine(exe != null ? Path.GetDirectoryName(exe) : ".", "probe.log");
                Log("doorstop entrypoint reached");
                Log("DOORSTOP_DLL_SEARCH_DIRS=" + Environment.GetEnvironmentVariable("DOORSTOP_DLL_SEARCH_DIRS"));
                Log("cwd=" + Environment.CurrentDirectory);
                try
                {
                    var asm = Assembly.Load("Assembly-CSharp");
                    Log("loaded Assembly-CSharp: " + asm.FullName);
                }
                catch (Exception e) { Log("Assembly.Load failed: " + e.Message); }

                try
                {
                    var go = new GameObject("probe");
                    Log("new GameObject OK");
                    UnityEngine.Object.DontDestroyOnLoad(go);
                    Log("DontDestroyOnLoad OK");
                    var comp = go.AddComponent<ProbeBehaviour>();
                    Log("AddComponent OK: " + (comp != null));
                }
                catch (Exception e) { Log("Unity API FAILED: " + e); }
            }
            catch (Exception e)
            {
                Log("outer fail: " + e);
            }
        }

        internal static void Log(string msg)
        {
            try { File.AppendAllText(_log, "[" + DateTime.Now.ToString("HH:mm:ss.fff") + "] " + msg + "\r\n"); }
            catch { }
        }
    }

    public class ProbeBehaviour : MonoBehaviour
    {
        private void Awake()
        {
            Entrypoint.Log("Awake called");
        }

        private void Start()
        {
            Entrypoint.Log("Start called on frame " + Time.frameCount);
        }

        private void Update()
        {
            if (Time.frameCount == 60) Entrypoint.Log("Update reached frame 60");
        }
    }
}
